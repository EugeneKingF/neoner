function clear_input() {
    document.getElementById("link").value = "";
}